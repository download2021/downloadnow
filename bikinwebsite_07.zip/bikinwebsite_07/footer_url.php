<a href="#">Home</a> | 
<a href="#">Blog</a> | 
<a href="#">Twitter</a> | 
<a href="#">Facebook</a> | 
<a href="#">Support</a> | 
<a href="#">Contact Us</a>