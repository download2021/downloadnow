<p>
<div style="color:#aaa;font-size:11px;">Advertising</div>
<div style="background-color:#eee;height:90px;width:100%;"></div>
</p>