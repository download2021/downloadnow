Theme Name: bikinwebsite_07
Theme URI: bikinwebsite.com
Description: BikinWebsite 07 is a stylish and professionally designed theme for anyone who wants to make a great blog site.
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Author: Mr.Shine
Author URI: bikinwebsite.com
Tags: white, gray, light
Version: 1.0